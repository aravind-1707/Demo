package com.practical.demo.Repository;

import static org.junit.jupiter.api.Assertions.*;

class Student_Respository_ImplementsTest {

}